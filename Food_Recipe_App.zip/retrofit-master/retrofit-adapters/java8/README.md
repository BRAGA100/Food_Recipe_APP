Java 8 Adapter (Deprecated)
===========================

A call adapter [Java 8's `CompletableFuture`][1].

This adapter is no longer needed. Support for `CompletableFuture` is built-in to Retrofit and now
works without configuration.


 [1]: http://www.oracle.com/technetwork/java/javase/jdk-8-readme-2095712.html
